package org.parse4j.custom;

import org.parse4j.ParseObject;

public class Person2 extends ParseObject {

}
