package main;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class CalculatorPanel extends JPanel{

}
