package main;

import javax.swing.JFrame;

@SuppressWarnings("serial")
public class Calculator extends JFrame{
	GraphPanel graphPanel;
	
	

}
