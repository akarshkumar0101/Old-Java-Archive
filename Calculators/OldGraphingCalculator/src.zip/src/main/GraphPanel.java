package main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import math.Phrase;

@SuppressWarnings("serial")
public class GraphPanel extends JPanel implements 
MouseListener, MouseMotionListener, MouseWheelListener, ComponentListener {
	
	public static final Font numFont = new Font("TimesRoman", Font.PLAIN, 25);
	
	public static final int MAX_NUM_FUNCTIONS = 8;
	
	public static final int yoffset = 25, xoffset = 14;
	
	private final JFrame parentFrame;
	
	public GraphParameters param;
	public ArrayList<Function> functs;
	private ArrayList<Function> editfuncts;
	private ArrayList<JTextField> functfields;
	private final ArrayList<JTextField> paramfields;
	private final JRadioButton paramShowAxisButton;
	
	private int mousemovex = 0, mousemovey = 0;// USED JUST FOR TRACKING MOUSE
	
	private final AddFunctionButton addFunctionButton;
	
	private final JButton functApplyButton;
	private final JButton settingsApplyButton;
	
	private final JButton functionsButton;
	private final JDialog functionsWindow;

	private final JButton settingsButton;
	private final JDialog settingsWindow;

	private final JPanel optionsPanel;
	
	private class AddFunctionButton extends JButton implements ActionListener{
		
		public AddFunctionButton(){
			super(getImage("add",50,50));
			this.addActionListener(this);
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			try {
				editfuncts.add(new Function(Phrase.createPhrase("")));
			} catch (Exception e1) {}
			cfgFunctionsWindow(editfuncts);
			functionsWindow.revalidate();
			functionsWindow.repaint();
		}
		
	}
	private class DialogDisplayer implements ActionListener {
		JDialog toOpen;
		public DialogDisplayer(JDialog toOpen) {
			super();
			this.toOpen = toOpen;
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			if(toOpen == functionsWindow) cfgFunctionsWindow(functs);
			else if(toOpen == settingsWindow) cfgSettingsWindow();
			toOpen.setVisible(true);
		}
	}
	private class FunctionRemoveButton extends JButton implements ActionListener{
		
		Function functToRemove;
		
		public FunctionRemoveButton(Function f){
			super(getImage("delete",50,50));
			functToRemove = f;
			this.setFont(numFont);
			this.addActionListener(this);
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			editfuncts.remove(functToRemove);
			cfgFunctionsWindow(editfuncts);
			functionsWindow.revalidate();
			functionsWindow.repaint();
		}
	}
	
	public GraphPanel(JFrame frame) {
		super();
		parentFrame = frame;
		param = GraphParameters.getDefaultParam();

		functs = new ArrayList<Function>();
		this.addMouseMotionListener(this);
		this.addMouseListener(this);
		this.addMouseWheelListener(this);
		this.addComponentListener(this);

		functionsWindow = new JDialog(frame, "Functions");
		functionsWindow.setModal(true);
		functionsWindow.setMinimumSize(new Dimension(900,900));
		functionsWindow.setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
		functionsWindow.setResizable(false);
		functionsWindow.setLocationRelativeTo(frame);

		settingsWindow = new JDialog(frame, "Settings");
		settingsWindow.setModal(true);
		settingsWindow.setMinimumSize(new Dimension(900, 900));
		settingsWindow.setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
		settingsWindow.setResizable(false);
		settingsWindow.setLocationRelativeTo(frame);
		
		functionsButton = new JButton("Functions");
		functionsButton.addActionListener(new DialogDisplayer(functionsWindow));
		functionsButton.setFont(numFont);
		settingsButton = new JButton("Settings");
		settingsButton.addActionListener(new DialogDisplayer(settingsWindow));
		settingsButton.setFont(numFont);

		optionsPanel = new JPanel();
		optionsPanel.setLayout(new GridLayout(1, 2));

		optionsPanel.add(functionsButton);
		optionsPanel.add(settingsButton);

		functionsWindow.setLayout(new GridLayout(MAX_NUM_FUNCTIONS+1,1));
		settingsWindow.setLayout(new GridLayout(6,1));
		
		functApplyButton = new JButton("Apply");
		functApplyButton.setFont(numFont);
		functApplyButton.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				functs.clear();
				for(int i=0; i <functfields.size(); i++){
					String funct = functfields.get(i).getText();
					if(funct.equals("")) continue;
					try {
						functs.add(new Function(Phrase.createPhrase(funct)));
					} catch (Exception e1) {
						JOptionPane.showMessageDialog(functionsWindow, "<html>y<sub>"+i+"</sub> is an invalid function</html>", "Error", JOptionPane.ERROR_MESSAGE, null);
					}
				}
				editfuncts = functs;
				functionsWindow.revalidate();
				functionsWindow.repaint();
				graphAllFunctions();
				repaint();
			}
		});
		settingsApplyButton = new JButton("Apply");
		settingsApplyButton.setFont(numFont);
		settingsApplyButton.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				double[] params = new double[4];
				try{
					params[0] = Double.parseDouble(paramfields.get(0).getText());
					params[1] = Double.parseDouble(paramfields.get(1).getText());
					params[2] = Double.parseDouble(paramfields.get(2).getText());
					params[3] = Double.parseDouble(paramfields.get(3).getText());
					
					if(params[1]<=params[0]||params[3] <= params[2])
						throw new Exception();
					
					param.minx = params[0];
					param.maxx = params[1];
					param.miny = params[2];
					param.maxy = params[3];
				}catch(Exception ex){
					System.err.println("Invalid parameters");
				}
				param.showaxis = paramShowAxisButton.isSelected();
				
				cfgSettingsWindow();
				settingsWindow.revalidate();
				settingsWindow.repaint();
				graphAllFunctions();
				repaint();
			}
		});
		
		addFunctionButton = new AddFunctionButton();
		addFunctionButton .setContentAreaFilled(false);
		addFunctionButton .setBorderPainted(false);
		
		functfields = new ArrayList<JTextField>();
		paramfields = new ArrayList<JTextField>();
		for(int i=0; i <4;i++){
			paramfields.add(new JTextField());
			paramfields.get(i).setFont(numFont);
		}
		paramShowAxisButton = new JRadioButton("Show Axis ");
		paramShowAxisButton.setFont(numFont);
		paramShowAxisButton.setHorizontalAlignment(JRadioButton.CENTER);
		paramShowAxisButton.setHorizontalTextPosition(JRadioButton.LEFT);
		
		this.setLayout(null);
		this.add(optionsPanel);

		cfgFunctionsWindow(functs);
		cfgSettingsWindow();
	}

	public void init() {
		graphAllFunctions();
		functionsWindow.setLocation((parentFrame.getWidth() - functionsWindow.getWidth())/2
				, (parentFrame.getHeight() - functionsWindow.getHeight())/2);
		settingsWindow.setLocation((parentFrame.getWidth() - functionsWindow.getWidth())/2
				, (parentFrame.getHeight() - functionsWindow.getHeight())/2);
		
		optionsPanel.setBounds(getWidth() - 300, 0, 300, 50);
		repaint();
	}
	
	private void cfgFunctionsWindow(ArrayList<Function> toDisplay) {
		functionsWindow.getContentPane().removeAll();
		
		editfuncts = new ArrayList<Function>(toDisplay);
		
		functfields.clear();
		
		for(int i=0; i <toDisplay.size(); i++){
			Function f = toDisplay.get(i);
			
			JPanel panel = new JPanel();
			panel.setLayout(new GridBagLayout());
			GridBagConstraints gbc = new GridBagConstraints();
			
			
			JLabel y = new JLabel("<html>y<sub>"+i+"</sub> = </html>");
			y.setFont(numFont);
			gbc.fill = GridBagConstraints.HORIZONTAL;
			gbc.ipadx = 20;
			gbc.gridx = 0;
		    gbc.gridy = 0;
		    panel.add(y, gbc);
			
			JPanel temppanel = new JPanel();
			JTextField function = new JTextField(f.phrase.toString());
			function.setPreferredSize(new Dimension(600,35));
			function.setFont(numFont);
			function.setBorder(BorderFactory.createLineBorder(Color.red));
			gbc.fill = GridBagConstraints.HORIZONTAL;
			gbc.ipadx = 600;
			gbc.gridx = 1;
		    gbc.gridy = 0;
		    functfields.add(function);
		    temppanel.add(function);
		    panel.add(temppanel, gbc);
			
		    FunctionRemoveButton removeb = new FunctionRemoveButton(f);
			gbc.fill = GridBagConstraints.HORIZONTAL;
			gbc.ipady= 0;
			gbc.ipadx = 0;
			gbc.gridx = 3;
		    gbc.gridy = 0;
		    removeb.setPreferredSize(new Dimension(50,50));
		    removeb.setContentAreaFilled(false);
		    removeb.setBorderPainted(false);
		    panel.add(removeb, gbc);
			
			
			functionsWindow.add(panel);
		}
		int addedbutton =0;
		if(toDisplay.size() < MAX_NUM_FUNCTIONS){
			addFunctionButton.setBorder(BorderFactory.createLineBorder(Color.red));
			functionsWindow.add(addFunctionButton);
			addedbutton++;
		}
		for(int i =toDisplay.size()+addedbutton;i < MAX_NUM_FUNCTIONS; i++){
			functionsWindow.add(new JLabel());
		}
		functionsWindow.add(functApplyButton);
		
	}

	private void cfgSettingsWindow() {
		settingsWindow.getContentPane().removeAll();
		
		paramfields.get(0).setText(param.minx+"");
		paramfields.get(1).setText(param.maxx+"");
		paramfields.get(2).setText(param.miny+"");
		paramfields.get(3).setText(param.maxy+"");
		
		GridBagConstraints gbc = new GridBagConstraints();
		for(int i=0; i <4; i++){
			JPanel panel = new JPanel();
			panel.setLayout(new GridBagLayout());
			
			JLabel paramname = new JLabel();
			paramname.setFont(numFont);
			if(i==0)paramname.setText("Min x: ");
			if(i==1)paramname.setText("Max x: ");
			if(i==2)paramname.setText("Min y: ");
			if(i==3)paramname.setText("Max y: ");
			
			gbc.fill = GridBagConstraints.HORIZONTAL;
			gbc.ipadx = 10;
			gbc.gridx = 0;
		    gbc.gridy = 0;
		    panel.add(paramname,gbc);
			
		    gbc.fill = GridBagConstraints.HORIZONTAL;
			gbc.ipadx = 200;
			gbc.gridx = 1;
		    gbc.gridy = 0;
		    paramfields.get(i).setFont(numFont);
		    panel.add(paramfields.get(i), gbc);
			settingsWindow.add(panel);
		}
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.ipadx = 200;
		gbc.gridx = 1;
	    gbc.gridy = 0;
	    paramShowAxisButton.setSelected(param.showaxis);
	    settingsWindow.add(paramShowAxisButton);
		settingsWindow.add(settingsApplyButton);
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.setColor(Color.BLACK);
		int actualcenterx = 0, actualcentery = 0;
		actualcenterx = (int) getScaledNumber(param.minx, param.maxx, 0, this.getWidth(), 0);
		actualcentery = (int) getScaledNumber(param.miny, param.maxy, getHeight(), 0, 0);
		g.setFont(numFont);
		if(param.showaxis){
			g.drawLine(actualcenterx, 0, actualcenterx, this.getHeight());
			g.drawLine(0, actualcentery, this.getWidth(), actualcentery);
			g.drawString("0", actualcenterx - xoffset, actualcentery + yoffset);
	
			g.drawString(param.maxx + "", getWidth() - xoffset * (param.maxx + "").length(), actualcentery + yoffset);
			g.drawString(param.minx + "", 0, actualcentery + yoffset);
			g.drawString(param.maxy + "", actualcenterx - xoffset * (param.maxy + "").length(), yoffset);
			g.drawString(param.miny + "", actualcenterx - xoffset * (param.miny + "").length(), getHeight() - yoffset);
		}
		double scale = (getWidth() / (param.maxx - param.minx));
		for (Function f : functs) {

			g.setColor(f.color);

			for (int i = 0; i < f.points.size() - 3; i = i + 2) {
				
				if (f.points.get(i + 1).isNaN() || f.points.get(i + 3).isNaN())
					continue;
				// if(f.points.get(i+3) > param.maxy ||f.points.get(i+3) <
				// param.miny) continue;
				// if(Math.abs(f.points.get(i+3)-f.points.get(i+1)) >
				// (param.maxy-param.miny)) continue;

				int x = (int) ((f.points.get(i) - param.minx) * scale);
				int y = (int) ((f.points.get(i + 1) + param.miny) * scale);
				int x2 = (int) ((f.points.get(i + 2) - param.minx) * scale);
				int y2 = (int) ((f.points.get(i + 3) + param.miny) * scale);

				x = (int) getScaledNumber(param.minx, param.maxx, 0, getWidth(), f.points.get(i));
				y = (int) getScaledNumber(param.miny, param.maxy, getHeight(), 0, f.points.get(i + 1));
				x2 = (int) getScaledNumber(param.minx, param.maxx, 0, getWidth(), f.points.get(i + 2));
				y2 = (int) getScaledNumber(param.miny, param.maxy, getHeight(), 0, f.points.get(i + 3));

				g.drawLine(x, y, x2, y2);
				// g.drawLine(0, 0, x2, y2);
				// g.drawLine(f.points.get(i), f.points.get(i + 1),
				// f.points.get(i + 2), f.points.get(i + 3));
			}
		}
	}
	private static ImageIcon getImage(String img, int x, int y){
		ImageIcon icon = new ImageIcon(GraphPanel.class.getResource("/img/"+img+ ".png"));
		Image image = icon.getImage();
		image = image.getScaledInstance(x, y, Image.SCALE_SMOOTH);
		icon = new ImageIcon(image);
		return icon;
	}

	public void graphFunction(Function f) {
		// System.out.println("Calculating");
		double res = (param.maxx - param.minx) / getWidth();

		f.points.clear();
		for (double x = param.minx; x <= param.maxx; x += res) {

			f.points.add(x);
			f.points.add(f.phrase.getValue(x));
			// System.out.println(x+" " +f.phrase.getValue(x));
		}
	}

	public void graphAllFunctions() {
		for (Function f : functs)
			graphFunction(f);
	}

	private double getScaledNumber(double ori1, double ori2, double scaleto1, double scaleto2, double number) {
		// move original scale down to zero
		number -= ori1;

		// get scale factor
		double scalefactor = (scaleto2 - scaleto1) / (ori2 - ori1);

		// scale to factor
		number *= scalefactor;

		// move up to required scale;
		number += scaleto1;

		return number;
	}

	@Override
	public void mouseDragged(MouseEvent e) { // NEEDED
		int newx = e.getX(), newy = getHeight() - e.getY();// new coord
		int changex = newx - mousemovex, changey = newy - mousemovey;

		double changewindowx = changex * (param.maxx - param.minx) / (getWidth());
		double changewindowy = changey * (param.maxy - param.miny) / (-getHeight());

		param.maxx -= changewindowx;
		param.minx -= changewindowx;
		param.maxy += changewindowy;
		param.miny += changewindowy;

		mousemovex = newx;
		mousemovey = newy;

		graphAllFunctions();
		repaint();
	}

	@Override
	public void mousePressed(MouseEvent e) { // NEEDED
		mousemovex = e.getX();
		mousemovey = getHeight() - e.getY();
		// System.out.println(mousemovex+" " + mousemovey);
	}
	@Override
	public void mouseWheelMoved(MouseWheelEvent event) {

		int moved = event.getWheelRotation();

		int mousex = event.getX();
		int mousey = event.getY();

		double graphmousex = (double) mousex / getWidth() * (param.maxx - param.minx) + param.minx;
		double graphmousey = ((1 - (double) mousey / getHeight()) * (param.maxy - param.miny) + param.miny);

		double maxx = param.maxx, minx = param.minx, maxy = param.maxy, miny = param.miny;

		param.maxx += moved * (maxx - graphmousex) / 10;
		param.minx -= moved * (graphmousex - minx) / 10;
		param.maxy += moved * (maxy - graphmousey) / 10;
		param.miny -= moved * (graphmousey - miny) / 10;

		graphAllFunctions();
		repaint();

	}

	@Override
	public void mouseReleased(MouseEvent e) {}
	@Override
	public void mouseMoved(MouseEvent e) {}
	@Override
	public void mouseClicked(MouseEvent e) {}
	@Override
	public void mouseEntered(MouseEvent e) {}
	@Override
	public void mouseExited(MouseEvent e) {}
	@Override
	public void componentResized(ComponentEvent e) {
		optionsPanel.setBounds(getWidth() - 300, 0, 300, 50);
	}
	@Override
	public void componentMoved(ComponentEvent e) {}
	@Override
	public void componentShown(ComponentEvent e) {}
	@Override
	public void componentHidden(ComponentEvent e) {}

}

class GraphParameters {
	public boolean showaxis;

	public double minx;
	public double maxx;
	public double miny;
	public double maxy;

	public GraphParameters(GraphParameters another) {
		showaxis = another.showaxis;

		minx = another.minx;
		maxx = another.maxx;
		miny = another.miny;
		maxy = another.maxy;
	}

	public GraphParameters() {
	}

	public static GraphParameters getDefaultParam() {
		GraphParameters param = new GraphParameters();

		param.minx = -10;
		param.maxx = 10;
		param.miny = -10;
		param.maxy = 10;

		param.showaxis = true;
		
		return param;
	}

	public boolean equals(GraphParameters another) {
		if (minx != another.minx)
			return false;
		if (maxx != another.maxx)
			return false;
		if (miny != another.miny)
			return false;
		if (maxy != another.maxy)
			return false;

		if (showaxis != another.showaxis)
			return false;

		return true;
	}

}