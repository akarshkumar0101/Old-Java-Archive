package main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JFrame;

import math.Phrase;

public class Main {
	public static final JFrame frame = new JFrame("Akarsh's Calculator 1.0!");

	public static void main(String[] args) throws Exception {

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(new GridLayout(1, 1));
		frame.setMinimumSize(new Dimension(625, 625));

		GraphPanel gp = new GraphPanel(frame);

		gp.functs.add(new Function(Phrase.createPhrase("e^x")));
		gp.functs.add(new Function(Phrase.createPhrase("sin(cos(tanx))")));
		gp.functs.add(new Function(Phrase.createPhrase("x*cosx")));
		gp.functs.add(new Function(Phrase.createPhrase("x")));

		frame.add(gp);

		frame.pack();
		frame.setSize(1000, 1000);

		gp.setBorder(BorderFactory.createLineBorder(Color.red));

		frame.setVisible(true);

		gp.init();

	}

}
