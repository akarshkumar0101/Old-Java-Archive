package math;

public class CalMath {

	public static double getValue(String inp) {
		inp = inp.replaceAll(" ", "");
		inp = "(" + inp + ")";
		Phrase p = null;
		try {
			p = Phrase.createPhrase(inp);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return p.getValue();
	}

}
