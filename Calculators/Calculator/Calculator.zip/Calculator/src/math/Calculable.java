package math;

abstract class Calculable {
	abstract double getValue();
}
