package main;

import java.util.Scanner;

public class Main {

	private static final Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		ClueAI ai = new ClueAI();

		String input = "";
		do {
			input = scan.nextLine();
			ai.handle(input);
		} while (!input.startsWith("Win"));

		scan.close();
	}

	public static ClueAI handleBeginning() {
		String idstr = scan.nextLine();
		String playercountstr = scan.nextLine();
		String boardstr = scan.nextLine();

		int id = Integer.parseInt(idstr.split(" ")[1]);
		int playercount = Integer.parseInt(idstr.split(" ")[1]);
		int boardlen = Integer.parseInt(boardstr.split(" ")[1]);

		Integer[][] board = new Integer[boardlen][boardlen];

		return null;
	}
}
