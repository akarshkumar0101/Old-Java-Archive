package main;

public class ClueAI {

	public static final String AI_NAME = "Akarsh's AI";

	public void handle(String input) {
		if (input.equals("Name")) {
			handleName();
		} else if (input.startsWith("Roomname")) {
			handleRoomname(input);
		} else if (input.startsWith("Weaponname")) {
			handleWeaponname(input);
		} else if (input.startsWith("Personname")) {
			handlePersonname(input);
		} else if (input.startsWith("Card")) {
			handleCard(input);
		} else if (input.startsWith("Move")) {
			handleMove(input);
		} else if (input.startsWith("Win")) {
			handleWin(input);
		}

	}

	public void handleName() {
		System.out.println(AI_NAME);
	}

	public void handleRoomname(String input) {

	}

	public void handleWeaponname(String input) {

	}

	public void handlePersonname(String input) {

	}

	public void handleCard(String input) {

	}

	public void handleMove(String input) {

	}

	public void handleWin(String input) {

	}
}
